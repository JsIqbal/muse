exports.id = 7355;
exports.ids = [7355];
exports.modules = {

/***/ 53119:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52990));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54390));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84102));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64092));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57460));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7048))

/***/ }),

/***/ 10059:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50954, 23))

/***/ }),

/***/ 57460:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"components/navbar.jsx","import":"Montserrat","arguments":[{"weight":"700","subsets":["latin"]}],"variableName":"montserrat"}
var navbar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_ = __webpack_require__(20601);
var navbar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_default = /*#__PURE__*/__webpack_require__.n(navbar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_);
// EXTERNAL MODULE: ./lib/utils.js
var utils = __webpack_require__(84493);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/ui/button.jsx
var ui_button = __webpack_require__(4187);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-dialog/dist/index.mjs + 5 modules
var dist = __webpack_require__(76980);
;// CONCATENATED MODULE: ./components/ui/dialog.jsx
/* __next_internal_client_entry_do_not_use__ Dialog,DialogTrigger,DialogContent,DialogHeader,DialogFooter,DialogTitle,DialogDescription auto */ 



const Dialog = dist/* Root */.fC;
const DialogTrigger = dist/* Trigger */.xz;
const DialogPortal = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Portal */.h_, {
        className: (0,utils.cn)(className),
        ...props
    });
DialogPortal.displayName = dist/* Portal */.h_.displayName;
const DialogOverlay = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Overlay */.aV, {
        ref: ref,
        className: (0,utils.cn)("fixed inset-0 z-50 bg-background/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props
    }));
DialogOverlay.displayName = dist/* Overlay */.aV.displayName;
const DialogContent = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogPortal, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DialogOverlay, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* Content */.VY, {
                ref: ref,
                className: (0,utils.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg md:w-full", className),
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* Close */.x8, {
                        className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                width: "30",
                                height: "20",
                                viewBox: "0 0 24 24",
                                fill: "none",
                                stroke: "currentColor",
                                "stroke-width": "2",
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                className: "lucide lucide-x h-6 w-6 text-bold",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M18 6 6 18"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "m6 6 12 12"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "sr-only",
                                children: "Close"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
DialogContent.displayName = dist/* Content */.VY.displayName;
const DialogHeader = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col space-y-1.5 text-center sm:text-left", className),
        ...props
    });
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    });
DialogFooter.displayName = "DialogFooter";
const DialogTitle = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Title */.Dx, {
        ref: ref,
        className: (0,utils.cn)("text-lg font-semibold leading-none tracking-tight", className),
        ...props
    }));
DialogTitle.displayName = dist/* Title */.Dx.displayName;
const DialogDescription = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Description */.dk, {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
DialogDescription.displayName = dist/* Description */.dk.displayName;


// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(66558);
// EXTERNAL MODULE: ./node_modules/@hookform/resolvers/zod/dist/zod.mjs + 1 modules
var zod = __webpack_require__(83894);
// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(19098);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var react_hot_toast_dist = __webpack_require__(10345);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(93258);
;// CONCATENATED MODULE: ./components/email-sending-form.jsx







// Define the schema for the form data
const schema = lib/* object */.Ry({
    email: lib/* string */.Z_().email().nonempty(),
    subject: lib/* string */.Z_().min(4),
    content: lib/* string */.Z_().min(10)
});
// Define the component for the form
const EmailForm = ()=>{
    // Use the useForm hook with the zod resolver
    const { register, handleSubmit, formState: { errors } } = (0,index_esm/* useForm */.cI)({
        resolver: (0,zod/* zodResolver */.F)(schema)
    });
    // Define the onSubmit function
    // Define the onSubmit function
    const onSubmit = async (data)=>{
        // Display a loading toast
        react_hot_toast_dist/* default */.ZP.loading("Sending email");
        // Define the API URL
        const API_URL = `${"http://localhost:3004"}/api/users/contact-us`;
        // Try to send the data to the API with Axios
        try {
            // Send a POST request with Axios and await for the response
            const response = await axios/* default */.Z.post(API_URL, data);
            // Check if the response is successful (status 200)
            if (response.status === 200) {
                react_hot_toast_dist/* default */.ZP.dismiss();
                // Display a success toast
                react_hot_toast_dist/* default */.ZP.success("Your Email was sent successfully!");
            } else {
                // Throw an error with the status text
                throw new Error(response.statusText);
            }
        } catch (error) {
            react_hot_toast_dist/* default */.ZP.dismiss();
            // Display an error toast
            console.error(error);
            react_hot_toast_dist/* default */.ZP.error("An error occurred during sending the email");
        }
    };
    // Return the JSX for the form
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        className: " bg-white rounded-lg space-y-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "md:text-4xl text-3xl font-bold text-center mb-8",
                children: "Contact us"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        htmlFor: "email",
                        className: "block text-sm font-medium text-gray-700",
                        children: "Your Email"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        id: "email",
                        ...register("email"),
                        className: "mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    }),
                    errors.email && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-red-600",
                        children: errors.email.message
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        htmlFor: "subject",
                        className: "block text-sm font-medium text-gray-700",
                        children: "Subject"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        id: "subject",
                        ...register("subject"),
                        className: "mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    }),
                    errors.subject && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-red-600",
                        children: errors.subject.message
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        htmlFor: "content",
                        className: "block text-sm font-medium text-gray-700",
                        children: "Message"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        id: "content",
                        ...register("content"),
                        rows: 4,
                        className: "mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    }),
                    errors.message && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-red-600",
                        children: errors.message.message
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    type: "submit",
                    className: "w-full bg-indigo-600 text-white font-bold py-2 px-4 rounded hover:bg-indigo-700",
                    children: "Send Email"
                })
            })
        ]
    });
};
/* harmony default export */ const email_sending_form = (EmailForm);

// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 54 modules
var esm = __webpack_require__(64470);
// EXTERNAL MODULE: ./components/ui/skeleton.jsx
var skeleton = __webpack_require__(47440);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(51158);
// EXTERNAL MODULE: ./hooks/use-cart.jsx
var use_cart = __webpack_require__(2803);
;// CONCATENATED MODULE: ./components/cart.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Cart = ()=>{
    const cart = (0,use_cart/* default */.Z)();
    const router = (0,navigation.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
        variant: "outline",
        onClick: ()=>router.push("/cart"),
        className: "space-x-2 relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* ShoppingBagIcon */.b_c, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                className: " h-max w-max font-semibold text-gray-800",
                onClick: ()=>{
                    cart.setCartBlinking(false);
                },
                children: [
                    "Go to cart",
                    " ",
                    cart.blink && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "absolute top-0 right-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "animate-ping absolute inline-flex h-4 w-4 rounded-full bg-blue-400 opacity-75",
                                style: {
                                    animationDuration: "2s"
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "absolute inline-flex rounded-full h-3 w-3 bg-blue-500"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const cart = (Cart);

;// CONCATENATED MODULE: ./components/navbar.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










const Navbar = ()=>{
    const { isSignedIn } = (0,esm/* useAuth */.aC)();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "fixed top-0 left-0 right-0 z-50 bg-gray-100 bg-opacity-93 shadow-md border-b-[1] border-slate-500",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between  p-4 container md:px-10  px:6",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                    href: "/",
                    className: "flex items-center justify-center gap-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative w-16 h-8 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                fill: true,
                                alt: "Logo",
                                src: "/icons/muse-icon.png"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: (0,utils.cn)("text-3xl text-blue-600", (navbar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_default()).className),
                            children: "Musesoft"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex gap-x-4 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/products",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                variant: "outline",
                                className: "w-max font-semibold text-gray-800",
                                children: "Our Products"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Dialog, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(DialogTrigger, {
                                    asChild: true,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                        className: "font-semibold text-gray-800",
                                        variant: "outline",
                                        children: "Contact us"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(DialogContent, {
                                    className: "container",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(email_sending_form, {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex gap-x-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(cart, {}),
                                isSignedIn ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex justify-center items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(esm/* ClerkLoading */.qI, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                                className: "h-10 w-10 rounded-full"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(esm/* ClerkLoaded */.a7, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(esm/* UserButton */.l8, {
                                                className: "h-10 w-10",
                                                afterSignOutUrl: "/"
                                            })
                                        })
                                    ]
                                }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/sign-up",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                        className: "bg-blue-600 w-max",
                                        children: "Sign up"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const navbar = (Navbar);


/***/ }),

/***/ 47440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ Skeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84493);


function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__.cn)("animate-pulse rounded-md bg-muted", className),
        ...props
    });
}



/***/ }),

/***/ 2803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(99715);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10345);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48228);



const useCart = (0,zustand__WEBPACK_IMPORTED_MODULE_1__/* .create */ .Ue)((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_2__/* .persist */ .tJ)((set, get)=>({
        items: [],
        blink: false,
        addItem: (data)=>{
            const currentItems = get().items;
            const existingItem = currentItems.find((item)=>item.id === data.id);
            if (existingItem) {
                return (0,react_hot_toast__WEBPACK_IMPORTED_MODULE_0__/* .toast */ .Am)("Item already in cart.");
            }
            set({
                items: [
                    ...get().items,
                    data
                ]
            });
            react_hot_toast__WEBPACK_IMPORTED_MODULE_0__/* .toast */ .Am.success("Item added to cart.");
            get().toggleBlink();
        },
        removeItem: (id)=>{
            set({
                items: [
                    ...get().items.filter((item)=>item.id !== id)
                ]
            });
            react_hot_toast__WEBPACK_IMPORTED_MODULE_0__/* .toast */ .Am.success("Item removed from cart.");
        },
        removeAll: ()=>set({
                items: []
            }),
        totalPrice: ()=>{
            return get().items.reduce((acc, cur)=>acc + cur.price.dollar, 0);
        },
        setCartBlinking: (bool)=>{
            set({
                blink: bool
            });
        },
        toggleBlink: ()=>{
            set({
                blink: true
            });
            setTimeout(()=>{
                set({
                    blink: false
                });
            }, 30000);
        }
    }), {
    name: "cart-storage",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_2__/* .createJSONStorage */ .FL)(()=>localStorage),
    // Skip hydration on the server-side
    skipHydration: "undefined" === "undefined"
}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCart);


/***/ }),

/***/ 16365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app/(user)/layout.js","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var layout_js_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(40559);
var layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(layout_js_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/navbar.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`/app/components/navbar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const navbar = (__default__);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(67272);
// EXTERNAL MODULE: ./lib/utils.js
var utils = __webpack_require__(43834);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(25124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/footer.jsx



const Footer = ({ className })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (0,utils.cn)("flex flex-col lg:flex-row w-full justify-center gap-x-[20%] gap-y-4 h-max mt-auto text-center bg-gray-800 text-white py-6 ", className),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "",
                children: [
                    "\xa9 2023 all rights reserved by",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "hover:underline",
                        href: "/",
                        children: "Musesoft"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-x-2 justify-center items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Developed by:"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "hover:underline",
                        href: "https://github.com/jsiqbal",
                        children: "Md. Iqbal Hossain"
                    }),
                    "&",
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "hover:underline",
                        href: "https://github.com/ahmad-munab",
                        children: "Ahmad Munab"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const footer = (Footer);

// EXTERNAL MODULE: ./node_modules/@clerk/nextjs/dist/esm/index.js + 21 modules
var esm = __webpack_require__(54205);
;// CONCATENATED MODULE: ./providers/toast-provider.jsx

const toast_provider_proxy = (0,module_proxy.createProxy)(String.raw`/app/providers/toast-provider.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: toast_provider_esModule, $$typeof: toast_provider_$$typeof } = toast_provider_proxy;
const toast_provider_default_ = toast_provider_proxy.default;

const e0 = toast_provider_proxy["ToastProvider"];

;// CONCATENATED MODULE: ./app/(user)/layout.js








const metadata = {
    title: "Musesoft",
    description: "A Developer Software Products Webstore",
    meta: [
        {
            name: "view-transition",
            content: "same-origin"
        }
    ]
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(esm/* ClerkProvider */.El, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("html", {
            lang: "en",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
                className: (0,utils.cn)((layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default()).className, "bg-white h-screen min-w-screen  max-w-screen  flex flex-col items-start overflow-x-hidden"),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(e0, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
                    children,
                    /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
                ]
            })
        })
    });
}


/***/ }),

/***/ 63546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25124);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const Custom404 = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-screen flex items-center justify-center bg-gray-700 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "card custom-top text-white text-center p-8 rounded-lg mx-4 sm:mx-auto",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "tools",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "circle",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "red box"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "circle",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "yellow box"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "circle",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "green box"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card__content mt-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-4xl font-semibold mb-4",
                            children: "404 - Page Not Found"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-gray-300 mb-4",
                            children: "The page you requested is not found."
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-gray-300 mb-4",
                            children: [
                                "If you believe this is an issue, please",
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    className: "text-blue-500 hover:underline ",
                                    href: "/contact-us",
                                    children: "contact us."
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "text-blue-500 hover:underline pb-4",
                            href: "/",
                            children: "Go back to home"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Custom404);


/***/ }),

/***/ 43834:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cn: () => (/* binding */ cn)
/* harmony export */ });
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95182);
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12794);


function cn(...inputs) {
    return (0,tailwind_merge__WEBPACK_IMPORTED_MODULE_0__/* .twMerge */ .m)((0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .W)(inputs));
}


/***/ }),

/***/ 67272:
/***/ (() => {



/***/ })

};
;