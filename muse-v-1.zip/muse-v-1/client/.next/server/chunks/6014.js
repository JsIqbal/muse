exports.id = 6014;
exports.ids = [6014];
exports.modules = {

/***/ 80650:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38174))

/***/ }),

/***/ 81048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(84493);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57114);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const RouteHeading = ({ route })=>{
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const Icon = route.icon;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onClick: ()=>router.push(route.href),
        className: "flex items-center justify-center  gap-6 cursor-pointer border p-3 my-4 w-min mx-auto rounded-lg shadow-sm hover:scale-[101.4%] transition duration-150",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("p-2 w-fit rounded-md", route.bgColor),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
                    className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("w-8 h-8", route.color)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "font-bold text-gray-800 md:text-3xl text-2xl w-max",
                children: route.label
            })
        ]
    }, route.href);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RouteHeading);


/***/ }),

/***/ 38174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/ui/button.jsx
var ui_button = __webpack_require__(4187);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(51158);
// EXTERNAL MODULE: ./components/ui/sheet.jsx
var sheet = __webpack_require__(45279);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app/admin/(routes)/components/sidebar.jsx","import":"Montserrat","arguments":[{"weight":"700","subsets":["latin"]}],"variableName":"montsserrat"}
var sidebar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montsserrat_ = __webpack_require__(39627);
var sidebar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montsserrat_default = /*#__PURE__*/__webpack_require__.n(sidebar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montsserrat_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./lib/utils.js
var utils = __webpack_require__(84493);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
;// CONCATENATED MODULE: ./app/admin/(routes)/components/sidebar-links.jsx





const SidebarLinks = ()=>{
    const routes = [
        {
            label: "Dashboard",
            icon: lucide_react/* LayoutDashboard */.yYn,
            href: "/admin",
            color: "text-purple-500"
        },
        {
            label: "Users",
            icon: lucide_react/* Users2Icon */.gDj,
            href: "/admin/users",
            color: "text-blue-500"
        },
        {
            label: "Emails",
            icon: lucide_react/* Mails */.dyy,
            href: "/admin/emails",
            color: "text-green-500"
        },
        {
            label: "Reviews",
            icon: lucide_react/* MessagesSquareIcon */.G43,
            href: "/admin/reviews",
            color: "text-yellow-500"
        },
        {
            label: "Upload",
            icon: lucide_react/* Upload */.gqx,
            href: "/admin/upload",
            color: "text-orange-500"
        }
    ];
    const pathname = (0,navigation.usePathname)();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "space-y-3 text-zinc-400 px-2 w-full",
        children: routes.map((route)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: route.href,
                className: (0,utils.cn)("group flex p-3 w-full justify-start cursor-pointer hover:text-white hover:bg-white/10 rounded-lg transition-all duration-150", pathname === route.href ? "bg-white/10 text-white" : ""),
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center flex-1",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(route.icon, {
                            className: (0,utils.cn)("h-8 w-8 mr-3", `${route.color}`)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-xl font-semibold",
                            children: route.label
                        })
                    ]
                })
            }, route.href);
        })
    });
};
/* harmony default export */ const sidebar_links = (SidebarLinks);

;// CONCATENATED MODULE: ./app/admin/(routes)/components/sidebar.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const Sidebar = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "space-y-4 py-2 flex flex-col h-full bg-[#111827] text-white",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "px-2 flex flex-col justify-start items-start flex-1",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                    href: "/admin",
                    className: "flex w-full items-center justify-center gap-4 mb-16 mt-6",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative w-16 h-8 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                fill: true,
                                alt: "Logo",
                                src: "/icons/muse-icon.png"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                            className: (0,utils.cn)("text-xl font-bold", (sidebar_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montsserrat_default()).className),
                            children: [
                                "Musesoft ",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                " Admin Panel"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(sidebar_links, {})
            ]
        })
    });
};
/* harmony default export */ const sidebar = (Sidebar);

;// CONCATENATED MODULE: ./app/admin/(routes)/components/mobile-sidebar.jsx





const MobileSidebar = ()=>{
    const [isMounted, setIsMounted] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        setIsMounted(true);
    }, []);
    if (!isMounted) {
        return null;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(sheet/* Sheet */.yo, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(sheet/* SheetTrigger */.aM, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "md:hidden",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(ButtonWrapper, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Menu */.v2r, {})
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sheet/* SheetContent */.ue, {
                side: "left",
                className: "m-0 p-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(sidebar, {})
            })
        ]
    });
};
const ButtonWrapper = ({ children })=>/*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "bg-transparent p-0 m-0 border-none cursor-pointer",
        children: children
    });
/* harmony default export */ const mobile_sidebar = (MobileSidebar);

// EXTERNAL MODULE: ./node_modules/js-cookie/dist/js.cookie.mjs
var js_cookie = __webpack_require__(72479);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(93258);
;// CONCATENATED MODULE: ./hooks/use-logout.js


const useLogout = ()=>{
    const logout = async ()=>{
        try {
            await axios/* default */.Z.post("http://localhost:3004/api/users/logout", {}, {
                withCredentials: true,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                }
            });
            localStorage.removeItem("token");
            localStorage.removeItem("isLoggedIn");
            localStorage.removeItem("userType");
            js_cookie/* default */.Z.remove("token");
        } catch (error) {
            console.error("Error while logging out:", error);
        }
    };
    return logout;
};
/* harmony default export */ const use_logout = (useLogout);

// EXTERNAL MODULE: ./providers/toast-provider.jsx
var toast_provider = __webpack_require__(7048);
;// CONCATENATED MODULE: ./app/admin/(routes)/layout.js
/* __next_internal_client_entry_do_not_use__ default auto */ 








const DashboardLayout = ({ children })=>{
    const router = (0,navigation.useRouter)();
    const [loaded, setLoaded] = (0,react_.useState)(false);
    const logout = use_logout();
    const handleLogout = async ()=>{
        await logout();
        router.push("/");
    };
    (0,react_.useEffect)(()=>{
        let token = js_cookie/* default */.Z.get("token");
        if (!token) return router.push("/admin/login");
        setLoaded(true);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex",
        children: loaded && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "hidden h-full lg:flex lg:w-72 lg:flex-col lg:fixed lg:inset-y-0 z-[80] bg-gray-900",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(sidebar, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col h-full w-full lg:ps-72",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(toast_provider.ToastProvider, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "w-full flex justify-between items-center shadow-md border-b p-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(mobile_sidebar, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                    onClick: handleLogout,
                                    className: "ms-auto font-semibold text-lg",
                                    size: "lg",
                                    children: "Log Out"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full h-full",
                            children: children
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layout = (DashboardLayout);


/***/ }),

/***/ 80929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_lucide_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(51158);

const routes = [
    {
        label: "Dashboard",
        icon: _node_modules_lucide_react__WEBPACK_IMPORTED_MODULE_0__/* .LayoutDashboard */ .yYn,
        href: "/admin",
        color: "text-purple-900",
        bgColor: "bg-purple-300"
    },
    {
        label: "Users",
        icon: _node_modules_lucide_react__WEBPACK_IMPORTED_MODULE_0__/* .Users2Icon */ .gDj,
        href: "/admin/users",
        color: "text-blue-900",
        bgColor: "bg-blue-300"
    },
    {
        label: "Emails",
        icon: _node_modules_lucide_react__WEBPACK_IMPORTED_MODULE_0__/* .Mails */ .dyy,
        href: "/admin/emails",
        color: "text-green-900",
        bgColor: "bg-green-300"
    },
    {
        label: "Reviews",
        icon: _node_modules_lucide_react__WEBPACK_IMPORTED_MODULE_0__/* .MessagesSquareIcon */ .G43,
        href: "/admin/reviews",
        color: "text-yellow-900",
        bgColor: "bg-yellow-300"
    },
    {
        label: "Upload Products",
        icon: _node_modules_lucide_react__WEBPACK_IMPORTED_MODULE_0__/* .Upload */ .gqx,
        href: "/admin/upload",
        color: "text-orange-900",
        bgColor: "bg-orange-300"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);


/***/ }),

/***/ 14640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/app/app/admin/(routes)/layout.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;