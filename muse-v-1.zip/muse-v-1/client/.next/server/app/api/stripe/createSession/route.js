"use strict";
(() => {
var exports = {};
exports.id = 7527;
exports.ids = [7527];
exports.modules = {

/***/ 32081:
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 13685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 73837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 98450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/stripe/createSession/route.js
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(42394);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(69692);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-kind.js
var route_kind = __webpack_require__(19513);
// EXTERNAL MODULE: ./node_modules/stripe/esm/stripe.esm.node.js + 111 modules
var stripe_esm_node = __webpack_require__(98679);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(89335);
;// CONCATENATED MODULE: ./app/api/stripe/createSession/route.js
// import Stripe from "stripe";
// const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
// import { NextResponse } from "next/server";
// export const POST = async (req) => {
//     const { items, userEmail, userId } = await req.json();
//     if (!items || !userEmail)
//         return NextResponse.json(
//             { message: "field items and userEmail not provided" },
//             { success: false }
//         );
//     let session;
//     try {
//         const line_items = items.map((item) => {
//             return {
//                 price_data: {
//                     currency: "usd",
//                     product_data: {
//                         name: item.name,
//                         images: [item.image],
//                         metadata: { productId: item.id },
//                     },
//                     unit_amount: item.price.dollar * 100,
//                 },
//                 quantity: 1,
//                 tax_rates: [`${process.env.NEXT_PUBLIC_PROD_TAX_ID}`],
//             };
//         });
//         session = await stripe.checkout.sessions.create({
//             payment_method_types: ["card"],
//             metadata: {
//                 userId,
//                 line_items: JSON.stringify(line_items), // Convert line_items to JSON string
//             },
//             success_url: `${process.env.CLIENT_URL}/my-products`,
//             cancel_url: `${process.env.CLIENT_URL}/cart`,
//             customer_email: userEmail,
//             mode: "payment",
//             line_items: line_items,
//         });
//     } catch (err) {
//         console.error(err);
//         return NextResponse.json({ message: err.message }, { success: false });
//     }
//     return NextResponse.json({ session_url: session.url }, { success: true });
// };

const stripe = new stripe_esm_node/* default */.Z(process.env.STRIPE_SECRET_KEY);

// Define the PurchaseRequest struct
class PurchaseRequest {
    constructor(userId, productIds){
        this.user_id = userId;
        this.product_ids = productIds;
    }
}
const POST = async (req)=>{
    const { items, userEmail, userId } = await req.json();
    if (!items || !userEmail) return next_response/* default */.Z.json({
        message: "field items and userEmail not provided"
    }, {
        success: false
    });
    let session;
    try {
        const line_items = items.map((item)=>{
            return {
                price_data: {
                    currency: "usd",
                    product_data: {
                        name: item.name,
                        images: [
                            item.image
                        ],
                        metadata: {
                            productId: item.id
                        }
                    },
                    unit_amount: item.price.dollar * 100
                },
                quantity: 1,
                tax_rates: [
                    `${"txr_1NtCUgCbEvwjmMQGAVH9FhOK"}`
                ]
            };
        });
        // Create a PurchaseRequest instance
        const purchaseRequest = new PurchaseRequest(userId, line_items.map((item)=>item.price_data.product_data.metadata.productId));
        session = await stripe.checkout.sessions.create({
            payment_method_types: [
                "card"
            ],
            metadata: {
                line_items: JSON.stringify(purchaseRequest)
            },
            success_url: `${process.env.CLIENT_URL}/my-products`,
            cancel_url: `${process.env.CLIENT_URL}/cart`,
            customer_email: userEmail,
            mode: "payment",
            line_items: line_items
        });
    } catch (err) {
        console.error(err);
        return next_response/* default */.Z.json({
            message: err.message
        }, {
            success: false
        });
    }
    return next_response/* default */.Z.json({
        session_url: session.url
    }, {
        success: true
    });
};

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fstripe%2FcreateSession%2Froute&name=app%2Fapi%2Fstripe%2FcreateSession%2Froute&pagePath=private-next-app-dir%2Fapi%2Fstripe%2FcreateSession%2Froute.js&appDir=%2Fapp%2Fapp&appPaths=%2Fapi%2Fstripe%2FcreateSession%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

// @ts-ignore this need to be imported from next/dist to be external


// @ts-expect-error - replaced by webpack/turbopack loader

const AppRouteRouteModule = app_route_module.AppRouteRouteModule;
// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = ""
const routeModule = new AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/stripe/createSession/route",
        pathname: "/api/stripe/createSession",
        filename: "route",
        bundlePath: "app/api/stripe/createSession/route"
    },
    resolvedPagePath: "/app/app/api/stripe/createSession/route.js",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { requestAsyncStorage , staticGenerationAsyncStorage , serverHooks , headerHooks , staticGenerationBailout  } = routeModule;
const originalPathname = "/api/stripe/createSession/route";


//# sourceMappingURL=app-route.js.map

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,4389,9335,9565,5501,8679], () => (__webpack_exec__(98450)));
module.exports = __webpack_exports__;

})();