(() => {
var exports = {};
exports.id = 4124;
exports.ids = [4124];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 35744:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        '(user)',
        {
        children: [
        'products',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 74510)), "/app/app/(user)/products/page.js"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94478)), "/app/app/(user)/products/layout.js"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54758)), "/app/app/(user)/products/loading.js"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16365)), "/app/app/(user)/layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 63546)), "/app/app/(user)/not-found.jsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["/app/app/(user)/products/page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/(user)/products/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/(user)/products/page",
        pathname: "/products",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 31130:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56822));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22870));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64261))

/***/ }),

/***/ 22870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ product_1)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/ui/button.jsx
var ui_button = __webpack_require__(4187);
// EXTERNAL MODULE: ./hooks/use-cart.jsx
var use_cart = __webpack_require__(2803);
// EXTERNAL MODULE: ./lib/utils.js
var utils = __webpack_require__(84493);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./components/tabs.jsx + 1 modules
var tabs = __webpack_require__(16911);
;// CONCATENATED MODULE: ./app/(user)/products/components/muse components/muse-overview.jsx

const Overview = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-wrap pb-8 pt-4 bg-gray-100 bg-opacity-93",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full md:w-2/3 pr-0 md:pr-8 mb-6 md:mb-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-4xl font-bold text-left text-gray-800 mb-6",
                        children: "Simplify | Aggregate | Automate | Simplify"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-disc pl-8 mb-6 text-gray-700",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "✨ Open Source - GPL3/EPL."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    "\uD83D\uDE80 Leverage Python / Jython to automate:",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "list-disc pl-8 mt-2 text-gray-600",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Middlewares like WebSphere, WebLogic, JBoss, Glassfish, and Tomcat over JMX (SSL/non-SSL)"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Linux SSH with agent-less connections"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDD25 Manage all 5 server types and Linux from one unified workspace."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDCA1 Familiar Eclipse-based Jython Development IDE, ready to roll."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDEE0️ Streamlined 4-Click Installer. Works on Win x64, Linux WINE x64. Bundled JVM."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDD27 Supports Java 8/9/10, Amazon Corretto, JETPack 13/14/16, IBM SDK."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "mb-6 text-blue-800",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "Now with Enhanced Auditing & Compliance."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "Unveiling powerful JBoss, GlassFish, Tomcat, and Linux Active Auditing Frameworks.",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "Quick-deploy Pega and Informatica with preset server compliance profiles."
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-disc pl-8 text-gray-700",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDCF7 Python-based Configuration Snapshots for Tomcat and Glassfish 2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83C\uDFD7️ Transform infrastructure into code. Automate the automation."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "⚙️ Embrace the Automation as-a Service Paradigm."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    "\uD83D\uDE80 Designed to run with the",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        // href="https://sourceforge.net/projects/jetpack"
                                        href: "#",
                                        className: "text-blue-800 hover:underline",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: "JETPack"
                                    }),
                                    " ",
                                    "platform."
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full md:w-1/3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "aspect-w-16 aspect-h-9",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                        width: "100%",
                        height: "100%",
                        src: "https://www.youtube.com/embed/cLhAHzlv4Bo",
                        title: "YouTube Video",
                        allowFullScreen: true,
                        className: "rounded-lg mt-10",
                        style: {
                            height: "400px"
                        }
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const muse_overview = (Overview);

;// CONCATENATED MODULE: ./app/(user)/products/components/muse components/muse-features.jsx

const Features = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "p-6 bg-gray-100 bg-opacity-93",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full md:w-1/2 pr-0 md:pr-8 mb-6 md:mb-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-2xl font-bold text-blue-800 mb-4",
                            children: "Features"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-gray-700 mb-6",
                            children: "Simplify | Aggregate | Automate | Simplify"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-disc pl-6 md:pl-8 text-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "mb-3 font-semibold",
                                    children: [
                                        "No deployed Agents",
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "font-normal",
                                            children: "required"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "mb-3 font-semibold",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Administer:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 md:pl-8 mt-2 text-gray-600",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "mb-2 font-semibold",
                                            children: "Linux (bash)"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            className: "mb-2 font-semibold",
                                            children: [
                                                "Jython - JMX",
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-disc pl-6 md:pl-8 mt-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "WebSphere"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "WebLogic"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "JBoss"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "Glassfish"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "Tomcat"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "mb-3 font-semibold",
                                    children: [
                                        "Jenkins - DevOps Pipeline",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list-disc pl-6 md:pl-8 mt-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Ansible -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Muse...."
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Muse -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Ansible...."
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Muse -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Linux SSH"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Muse -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Middleware"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full md:w-1/2 pl-0 md:pl-8",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-disc pl-6 md:pl-8 text-gray-700",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Simultaneously",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "from ONE ide."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Sample"
                                    }),
                                    " Scripts for ALL 5 Servers INCLUDED..."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Live Connection to",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "GIT Repository."
                                    }),
                                    " ",
                                    "Get updates in minutes..."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Apply",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "SSL Configuration"
                                    }),
                                    " ",
                                    "to unlimited servers in 2 clicks."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Performance Tune your Multi-Server Pega Estate",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "in 2 clicks."
                                    }),
                                    " ",
                                    "(JBoss)"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Upgrade",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Vendor Applications"
                                    }),
                                    " ",
                                    "on unlimited servers",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "in 2 clicks."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Secure",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "SSL/TLS Trust Stores"
                                    }),
                                    " ",
                                    "Provisioned."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Schedule Automation",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "with Jenkins"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list-disc pl-6 md:pl-8 mt-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "mb-1 font-semibold",
                                        children: [
                                            "Extract Eclipse Launch",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-normal",
                                                children: "Configuration"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "mb-1 font-semibold",
                                        children: [
                                            "Use it directly",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-normal",
                                                children: "in a Jenkins"
                                            }),
                                            " ",
                                            "Build Job"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "We invite",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Vendors"
                                    }),
                                    " and Systems Integrators with Complex Deployment Needs",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "to work"
                                    }),
                                    " with us.",
                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        className: "list-disc pl-6 md:pl-8 mt-2",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            className: "mb-1 font-semibold",
                                            children: [
                                                "Oracle, IBM, RedHat, Apache and Eclipse Foundation pack",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-normal",
                                                    children: "Ultimate Middleware Firepower"
                                                }),
                                                " ",
                                                "!!!"
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const muse_features = (Features);

;// CONCATENATED MODULE: ./app/(user)/products/components/muse components/muse-benefits.jsx

const Benefit = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mt-8 mb-8",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-xl font-semibold text-gray-800",
                children: "Benefits"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap mt-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-disc pl-6 text-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Open Source - ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "GPL3/EPL licensed."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Effortless ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Automation:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Automate",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "WebSphere, WebLogic, JBoss, Glassfish, and Tomcat Middleware Estates"
                                                }),
                                                " ",
                                                "over JMX (SSL/non-SSL)."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Streamline ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Linux SSH"
                                                }),
                                                " without requiring agents."
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Unified ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Workspace:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Target all ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "5 servers"
                                                }),
                                                " and",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Linux"
                                                }),
                                                " from a single workspace."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Benefit from a familiar",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Eclipse-based Jython Development IDE."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Quick and Easy ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Setup:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Install effortlessly with a",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "4-click installer."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Compatibility with",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Java 8/9/10, Amazon Corretto, JETPack13/14/16, IBM SDK."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Enhanced ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Auditing & Compliance:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Utilize powerful",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "JBoss/GlassFish/Tomcat/Linux Active Auditing Framework."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Deploy ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Pega and Informatica"
                                                }),
                                                " ",
                                                "with preset server compliance profiles."
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-disc pl-6 text-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Python-based Configuration Snapshots"
                                        }),
                                        " ",
                                        "for ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Tomcat and Glassfish."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Infrastructure-as-Code:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Transform infrastructure into",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "code."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Automate the",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "automation process."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Automation-as-a-Service:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Embrace the concept of",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Automation as-a Service."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Designed to run on the",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "JETPack platform."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Streamlined Management:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Reduce complexity of",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "deployments and change control."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Unified administration point for",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "server farms with multiple vendors."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Vendor Support:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Develop",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Jython Scriptlets and access the Dynatrace API"
                                                }),
                                                " ",
                                                "with ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Dynatrace support."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Work efficiently with",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "complex JEE Infrastructure and Software."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Vendor support for",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "RedHat (JBoss), Oracle (SOA Suite, WebLogic), IBM (WebSphere), Pega Systems, Informatica,"
                                                }),
                                                " ",
                                                "and more."
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const muse_benefits = (Benefit);

;// CONCATENATED MODULE: ./app/(user)/products/components/muse components/museTabs.jsx





const MuseTabs = ()=>{
    const tabsData = {
        tabList: [
            {
                value: "Overview",
                label: "Overview"
            },
            {
                value: "Features",
                label: "Features"
            },
            {
                value: "Benefits",
                label: "Benefits"
            }
        ],
        tabContent: [
            {
                value: "Overview",
                text: /*#__PURE__*/ jsx_runtime_.jsx(muse_overview, {})
            },
            {
                value: "Features",
                text: /*#__PURE__*/ jsx_runtime_.jsx(muse_features, {})
            },
            {
                value: "Benefits",
                text: /*#__PURE__*/ jsx_runtime_.jsx(muse_benefits, {})
            }
        ]
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full my-10 bg-gray-100 bg-opacity-93 animate-fade-in-down",
        children: /*#__PURE__*/ jsx_runtime_.jsx(tabs/* default */.Z, {
            tabsData: tabsData
        })
    });
};
/* harmony default export */ const museTabs = (MuseTabs);

;// CONCATENATED MODULE: ./app/(user)/products/components/product-1.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const Product1 = ()=>{
    const [showMore, setShowMore] = (0,react_.useState)(true);
    const cart = (0,use_cart/* default */.Z)();
    const data = {
        id: `${"prod_OgYx4oNsmeRyaX"}`,
        name: "Muse",
        price: {
            id: `${"price_1NtBpICbEvwjmMQGttw9mSYE"}`,
            dollar: 20
        },
        images: [
            "https://files.stripe.com/links/MDB8YWNjdF8xTmR5ZGlIeWphTkNJM3JFfGZsX3Rlc3RfNVR5THV6UWVQMG9zdUlkS3g5MW9JQ2FZ00NAoHmUpY"
        ]
    };
    // Will be added to cart
    function onAddToCart() {
        cart.addItem(data);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-screen  bg-white flex flex-col py-8 2xl:px-0 px-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex lg:flex-row flex-col justify-between items-center container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "lg:w-[50%] w-full flex flex-col justify-center items-start gap-y-8 animate-fade-in-left",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-y-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                    className: "text-3xl font-bold text-gray-900",
                                    children: [
                                        "Muse: Middleware Universal ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        " Scripting idE"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-lg",
                                    children: "Muse empowers you to automate WebSphere, WebLogic, JBoss, Glassfish, and Tomcat Middleware Estates over JMX using Python / Jython. With its user-friendly Eclipse-based Jython Development IDE, you can streamline your workflow and simplify server management."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-8 space-y-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[1rem] text-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "font-semibold",
                                                    children: "Features:"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "mt-2 space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                                    className: "flex-shrink-0 h-4 w-4 text-green-500",
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    fill: "none",
                                                                    viewBox: "0 0 24 24",
                                                                    stroke: "currentColor",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: "2",
                                                                        d: "M5 13l4 4L19 7"
                                                                    })
                                                                }),
                                                                "Simplify, Aggregate, Automate..."
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "ml-5",
                                                            children: "Manage Linux, WebSphere, WebLogic, JBoss, Glassfish, Tomcat through JMX and Linux SSH without agents."
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                                    className: "flex-shrink-0 h-4 w-4 text-green-500",
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    fill: "none",
                                                                    viewBox: "0 0 24 24",
                                                                    stroke: "currentColor",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: "2",
                                                                        d: "M5 13l4 4L19 7"
                                                                    })
                                                                }),
                                                                "Sample Scripts Included"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "ml-5",
                                                            children: "Access GIT Repository, apply SSL Configuration in clicks. Performance Tune Pega (JBoss), Upgrade Vendor Apps, Build WebLogic Domains quickly."
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-lg text-gray-700",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "mt-4 flex gap-x-4",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                                        className: "bg-blue-500",
                                                        onClick: onAddToCart,
                                                        children: "Add to cart"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                                        variant: "outline",
                                                        onClick: ()=>{
                                                            setShowMore(!showMore);
                                                            const section = document.querySelector("#museMoreInfo");
                                                            if (!showMore) {
                                                                section.scrollIntoView({
                                                                    behavior: "smooth"
                                                                });
                                                            }
                                                        },
                                                        children: [
                                                            "Details",
                                                            " ",
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                width: "24",
                                                                height: "24",
                                                                viewBox: "0 0 24 24",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                "stroke-width": "2",
                                                                "stroke-linecap": "round",
                                                                "stroke-linejoin": "round",
                                                                className: (0,utils.cn)("lucide lucide-arrow-right ml-3 transition-all duration-300", showMore && "rotate-90"),
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        d: "M5 12h14"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        d: "m12 5 7 7-7 7"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "lg:w-[50%] flex justify-end w-max md:py-[7%] py-[9%] animate-fade-in-down",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative rounded-md",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/images/dummy-pic-1.PNG",
                                width: 450,
                                height: 450,
                                alt: "demo picture"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "museMoreInfo",
                className: (0,utils.cn)("transition-all duration-700 container ", showMore ? "h-[44rem]" : "h-0 invisible"),
                children: /*#__PURE__*/ jsx_runtime_.jsx(museTabs, {})
            })
        ]
    });
};
/* harmony default export */ const product_1 = (Product1);


/***/ }),

/***/ 64261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ product_2)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/ui/button.jsx
var ui_button = __webpack_require__(4187);
// EXTERNAL MODULE: ./hooks/use-cart.jsx
var use_cart = __webpack_require__(2803);
// EXTERNAL MODULE: ./lib/utils.js
var utils = __webpack_require__(84493);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./components/tabs.jsx + 1 modules
var tabs = __webpack_require__(16911);
;// CONCATENATED MODULE: ./app/(user)/products/components/JETPack components/jetPack-overview.jsx

const Overview = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-wrap pb-8 pt-4 bg-gray-100 bg-opacity-93",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full md:w-2/3 pr-0 md:pr-8 mb-6 md:mb-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-4xl font-bold text-left text-gray-800 mb-6",
                        children: "Simplify | Aggregate | Automate | Simplify"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-disc pl-8 mb-6 text-gray-700",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "✨ Open Source - GPL3/EPL."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    "\uD83D\uDE80 Leverage Python / Jython to automate:",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "list-disc pl-8 mt-2 text-gray-600",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Middlewares like WebSphere, WebLogic, JBoss, Glassfish, and Tomcat over JMX (SSL/non-SSL)"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Linux SSH with agent-less connections"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDD25 Manage all 5 server types and Linux from one unified workspace."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDCA1 Familiar Eclipse-based Jython Development IDE, ready to roll."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDEE0️ Streamlined 4-Click Installer. Works on Win x64, Linux WINE x64. Bundled JVM."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDD27 Supports Java 8/9/10, Amazon Corretto, JETPack 13/14/16, IBM SDK."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "mb-6 text-blue-800",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: "Now with Enhanced Auditing & Compliance."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "Unveiling powerful JBoss, GlassFish, Tomcat, and Linux Active Auditing Frameworks.",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "Quick-deploy Pega and Informatica with preset server compliance profiles."
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-disc pl-8 text-gray-700",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83D\uDCF7 Python-based Configuration Snapshots for Tomcat and Glassfish 2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "\uD83C\uDFD7️ Transform infrastructure into code. Automate the automation."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: "⚙️ Embrace the Automation as-a Service Paradigm."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    "\uD83D\uDE80 Designed to run with the",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        // href="https://sourceforge.net/projects/jetpack"
                                        href: "#",
                                        className: "text-blue-800 hover:underline",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: "JETPack"
                                    }),
                                    " ",
                                    "platform."
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full md:w-1/3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "aspect-w-16 aspect-h-9",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                        width: "100%",
                        height: "100%",
                        src: "https://www.youtube.com/embed/cLhAHzlv4Bo",
                        title: "YouTube Video",
                        allowFullScreen: true,
                        className: "rounded-lg mt-10",
                        style: {
                            height: "400px"
                        }
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const jetPack_overview = (Overview);

;// CONCATENATED MODULE: ./app/(user)/products/components/JETPack components/jetPack-features.jsx

const Features = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "p-6 bg-gray-100 bg-opacity-93",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full md:w-1/2 pr-0 md:pr-8 mb-6 md:mb-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-2xl font-bold text-blue-800 mb-4",
                            children: "Features"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-gray-700 mb-6",
                            children: "Simplify | Aggregate | Automate | Simplify"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-disc pl-6 md:pl-8 text-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "mb-3 font-semibold",
                                    children: [
                                        "No deployed Agents",
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "font-normal",
                                            children: "required"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "mb-3 font-semibold",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Administer:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 md:pl-8 mt-2 text-gray-600",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "mb-2 font-semibold",
                                            children: "Linux (bash)"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            className: "mb-2 font-semibold",
                                            children: [
                                                "Jython - JMX",
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-disc pl-6 md:pl-8 mt-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "WebSphere"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "WebLogic"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "JBoss"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "Glassfish"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "mb-1 font-semibold",
                                                            children: "Tomcat"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "mb-3 font-semibold",
                                    children: [
                                        "Jenkins - DevOps Pipeline",
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list-disc pl-6 md:pl-8 mt-2",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Ansible -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Muse...."
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Muse -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Ansible...."
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Muse -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Linux SSH"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mb-2 font-semibold",
                                                    children: [
                                                        "Muse -",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-normal",
                                                            children: "Middleware"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full md:w-1/2 pl-0 md:pl-8",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-disc pl-6 md:pl-8 text-gray-700",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Simultaneously",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "from ONE ide."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Sample"
                                    }),
                                    " Scripts for ALL 5 Servers INCLUDED..."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Live Connection to",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "GIT Repository."
                                    }),
                                    " ",
                                    "Get updates in minutes..."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Apply",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "SSL Configuration"
                                    }),
                                    " ",
                                    "to unlimited servers in 2 clicks."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Performance Tune your Multi-Server Pega Estate",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "in 2 clicks."
                                    }),
                                    " ",
                                    "(JBoss)"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Upgrade",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Vendor Applications"
                                    }),
                                    " ",
                                    "on unlimited servers",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "in 2 clicks."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Secure",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "SSL/TLS Trust Stores"
                                    }),
                                    " ",
                                    "Provisioned."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "Schedule Automation",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "with Jenkins"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list-disc pl-6 md:pl-8 mt-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "mb-1 font-semibold",
                                        children: [
                                            "Extract Eclipse Launch",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-normal",
                                                children: "Configuration"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "mb-1 font-semibold",
                                        children: [
                                            "Use it directly",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-normal",
                                                children: "in a Jenkins"
                                            }),
                                            " ",
                                            "Build Job"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "mb-3 font-semibold",
                                children: [
                                    "We invite",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "Vendors"
                                    }),
                                    " and Systems Integrators with Complex Deployment Needs",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-normal",
                                        children: "to work"
                                    }),
                                    " with us.",
                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        className: "list-disc pl-6 md:pl-8 mt-2",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            className: "mb-1 font-semibold",
                                            children: [
                                                "Oracle, IBM, RedHat, Apache and Eclipse Foundation pack",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-normal",
                                                    children: "Ultimate Middleware Firepower"
                                                }),
                                                " ",
                                                "!!!"
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const jetPack_features = (Features);

;// CONCATENATED MODULE: ./app/(user)/products/components/JETPack components/jetPack-benefits.jsx

const Benefit = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mt-8 mb-8",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-xl font-semibold text-gray-800",
                children: "Benefits"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap mt-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-disc pl-6 text-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Open Source - ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "GPL3/EPL licensed."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Effortless ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Automation:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Automate",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "WebSphere, WebLogic, JBoss, Glassfish, and Tomcat Middleware Estates"
                                                }),
                                                " ",
                                                "over JMX (SSL/non-SSL)."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Streamline ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Linux SSH"
                                                }),
                                                " without requiring agents."
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Unified ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Workspace:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Target all ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "5 servers"
                                                }),
                                                " and",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Linux"
                                                }),
                                                " from a single workspace."
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Benefit from a familiar",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Eclipse-based Jython Development IDE."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Quick and Easy ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Setup:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Install effortlessly with a",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "4-click installer."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Compatibility with",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Java 8/9/10, Amazon Corretto, JETPack13/14/16, IBM SDK."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "Enhanced ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Auditing & Compliance:"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Utilize powerful",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "JBoss/GlassFish/Tomcat/Linux Active Auditing Framework."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Deploy ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Pega and Informatica"
                                                }),
                                                " ",
                                                "with preset server compliance profiles."
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-disc pl-6 text-gray-700",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Python-based Configuration Snapshots"
                                        }),
                                        " ",
                                        "for ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Tomcat and Glassfish."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Infrastructure-as-Code:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Transform infrastructure into",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "code."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Automate the",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "automation process."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Automation-as-a-Service:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Embrace the concept of",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Automation as-a Service."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Designed to run on the",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "JETPack platform."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Streamlined Management:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Reduce complexity of",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "deployments and change control."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Unified administration point for",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "server farms with multiple vendors."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: "Vendor Support:"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-disc pl-6 mt-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Develop",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Jython Scriptlets and access the Dynatrace API"
                                                }),
                                                " ",
                                                "with ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "Dynatrace support."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Work efficiently with",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "complex JEE Infrastructure and Software."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                "Vendor support for",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                    children: "RedHat (JBoss), Oracle (SOA Suite, WebLogic), IBM (WebSphere), Pega Systems, Informatica,"
                                                }),
                                                " ",
                                                "and more."
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const jetPack_benefits = (Benefit);

;// CONCATENATED MODULE: ./app/(user)/products/components/JETPack components/jetPackTabs.jsx





const JETPackTabs = ()=>{
    const tabsData = {
        tabList: [
            {
                value: "Overview",
                label: "Overview"
            },
            {
                value: "Features",
                label: "Features"
            },
            {
                value: "Benefits",
                label: "Benefits"
            }
        ],
        tabContent: [
            {
                value: "Overview",
                text: /*#__PURE__*/ jsx_runtime_.jsx(jetPack_overview, {})
            },
            {
                value: "Features",
                text: /*#__PURE__*/ jsx_runtime_.jsx(jetPack_features, {})
            },
            {
                value: "Benefits",
                text: /*#__PURE__*/ jsx_runtime_.jsx(jetPack_benefits, {})
            }
        ]
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full my-10 bg-gray-100 bg-opacity-93 animate-fade-in-down",
        children: /*#__PURE__*/ jsx_runtime_.jsx(tabs/* default */.Z, {
            tabsData: tabsData
        })
    });
};
/* harmony default export */ const jetPackTabs = (JETPackTabs);

// EXTERNAL MODULE: ./components/ui/separator.jsx
var separator = __webpack_require__(56822);
;// CONCATENATED MODULE: ./app/(user)/products/components/product-2.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const Product2 = ()=>{
    const [showMore, setShowMore] = (0,react_.useState)(true);
    const cart = (0,use_cart/* default */.Z)();
    const data = {
        id: `${"prod_OgYmezTEK4fZ8Z"}`,
        name: "JETPack",
        price: {
            id: `${"price_1NtBeoCbEvwjmMQGoISQ5jW2"}`,
            dollar: 12
        },
        images: [
            "https://files.stripe.com/links/MDB8YWNjdF8xTmR5ZGlIeWphTkNJM3JFfGZsX3Rlc3RfdjlFWkZaWmVBRU93b2VUTTN2dVNxRk0x00fWNkumMi"
        ]
    };
    // Will be added to cart
    function onAddToCart() {
        cart.addItem(data);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-screen py-8 2xl:px-0 px-8 bg-[#F2F6F9]  animate-fade-in-down",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex lg:flex-row flex-col justify-between items-center container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "lg:w-[50%] flex justify-start w-max md:py-[7%] py-[9%] animate-fade-in-down",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative rounded-md",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/images/dummy-pic-1.PNG",
                                width: 450,
                                height: 450,
                                alt: "demo picture"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "lg:w-[50%] w-full flex flex-col justify-center items-start gap-y-8 animate-fade-in-right",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-y-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "text-3xl font-bold text-gray-900",
                                    children: "JETPack - Empowering Java Development and Diagnostics:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-lg",
                                    children: "JET Pack offers essential tools for Java developers, encompassing OpenSource JDKs from Java 13 to 19. It includes Visual VM, JConsole, and MissionControl, providing powerful diagnostic capabilities to profile and optimize your code."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-8 space-y-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[1rem] text-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "font-semibold",
                                                    children: "Features:"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "mt-2 space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                                    className: "flex-shrink-0 h-4 w-4 text-green-500",
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    fill: "none",
                                                                    viewBox: "0 0 24 24",
                                                                    stroke: "currentColor",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: "2",
                                                                        d: "M5 13l4 4L19 7"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    className: "ml-1",
                                                                    children: "OpenSource Java JDK Support: JETPack integrates with Java JDKs 13-19, empowering developers to leverage open-source Java advancements."
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                                    className: "flex-shrink-0 h-4 w-4 text-green-500",
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    fill: "none",
                                                                    viewBox: "0 0 24 24",
                                                                    stroke: "currentColor",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: "2",
                                                                        d: "M5 13l4 4L19 7"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    className: "ml-1",
                                                                    children: "Efficient Diagnostics: Tools like Visual VM, JConsole, and MissionControl offer real-time insights into memory usage, CPU performance, and smarter decision-making."
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex items-start",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                                    className: "flex-shrink-0 h-4 w-4 text-green-500",
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    fill: "none",
                                                                    viewBox: "0 0 24 24",
                                                                    stroke: "currentColor",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: "2",
                                                                        d: "M5 13l4 4L19 7"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    className: "ml-1",
                                                                    children: "Precise Performance Boost: Diagnose memory leaks, manage heap dumps, and profile CPU and memory usage with precision. Enhance efficiency and application behavior over time."
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-lg text-gray-700",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "mt-4 flex gap-x-4",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                                        className: "bg-blue-500",
                                                        onClick: onAddToCart,
                                                        children: "Add to cart"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                                        variant: "outline",
                                                        onClick: ()=>{
                                                            setShowMore(!showMore);
                                                            if (!showMore) {
                                                                const section = document.querySelector("#jetPackMoreInfo");
                                                                section.scrollIntoView({
                                                                    behavior: "smooth"
                                                                });
                                                            }
                                                        },
                                                        children: [
                                                            "Details",
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                width: "24",
                                                                height: "24",
                                                                viewBox: "0 0 24 24",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                "stroke-width": "2",
                                                                "stroke-linecap": "round",
                                                                "stroke-linejoin": "round",
                                                                className: (0,utils.cn)("lucide lucide-arrow-right ml-3 transition-all duration-300", showMore && "rotate-90"),
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        d: "M5 12h14"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                        d: "m12 5 7 7-7 7"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "jetPackMoreInfo",
                className: (0,utils.cn)("transition-all duration-700 container delay-75", showMore ? " opacity-100" : " opacity-0"),
                children: /*#__PURE__*/ jsx_runtime_.jsx(jetPackTabs, {})
            })
        ]
    });
};
/* harmony default export */ const product_2 = (Product2);


/***/ }),

/***/ 16911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ tabs)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-tabs/dist/index.mjs + 3 modules
var dist = __webpack_require__(94649);
// EXTERNAL MODULE: ./lib/utils.js
var utils = __webpack_require__(84493);
;// CONCATENATED MODULE: ./components/ui/tabs.jsx
/* __next_internal_client_entry_do_not_use__ Tabs,TabsList,TabsTrigger,TabsContent auto */ 



const Tabs = dist/* Root */.fC;
const TabsList = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* List */.aV, {
        ref: ref,
        className: (0,utils.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }));
TabsList.displayName = dist/* List */.aV.displayName;
const TabsTrigger = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Trigger */.xz, {
        ref: ref,
        className: (0,utils.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }));
TabsTrigger.displayName = dist/* Trigger */.xz.displayName;
const TabsContent = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Content */.VY, {
        ref: ref,
        className: (0,utils.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }));
TabsContent.displayName = dist/* Content */.VY.displayName;


// EXTERNAL MODULE: ./components/ui/separator.jsx
var separator = __webpack_require__(56822);
;// CONCATENATED MODULE: ./components/tabs.jsx



const CommonTabs = ({ tabsData })=>{
    const { tabList, tabContent } = tabsData;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Tabs, {
        defaultValue: tabList[0].value,
        className: "w-full shadow-lg rounded-lg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TabsList, {
                children: tabList.map((tab)=>/*#__PURE__*/ jsx_runtime_.jsx(TabsTrigger, {
                        value: tab.value,
                        children: tab.label
                    }, tab.value))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator.Separator, {
                className: "w-full"
            }),
            tabList.map((tab)=>/*#__PURE__*/ jsx_runtime_.jsx(TabsContent, {
                    className: "container",
                    value: tab.value,
                    children: tabContent.find((content)=>content.value === tab.value)?.text
                }, tab.value))
        ]
    });
};
/* harmony default export */ const tabs = (CommonTabs);


/***/ }),

/***/ 94478:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const metadata = {
    meta: [
        {
            name: "view-transition",
            content: "same-origin"
        }
    ]
};
const Layout = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mt-28 w-full h-max flex justify-center items-center",
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);


/***/ }),

/***/ 54758:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_spinner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19042);


const CartLoading = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_spinner__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            size: 16
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartLoading);


/***/ }),

/***/ 74510:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./components/ui/separator.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`/app/components/ui/separator.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Separator"];

;// CONCATENATED MODULE: ./app/(user)/products/components/product-1.jsx

const product_1_proxy = (0,module_proxy.createProxy)(String.raw`/app/app/(user)/products/components/product-1.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: product_1_esModule, $$typeof: product_1_$$typeof } = product_1_proxy;
const product_1_default_ = product_1_proxy.default;


/* harmony default export */ const product_1 = (product_1_default_);
;// CONCATENATED MODULE: ./app/(user)/products/components/product-2.jsx

const product_2_proxy = (0,module_proxy.createProxy)(String.raw`/app/app/(user)/products/components/product-2.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: product_2_esModule, $$typeof: product_2_$$typeof } = product_2_proxy;
const product_2_default_ = product_2_proxy.default;


/* harmony default export */ const product_2 = (product_2_default_);
;// CONCATENATED MODULE: ./app/(user)/products/page.js




const ProdcutsPage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(product_1, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                className: "h-1.5"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(product_2, {})
        ]
    });
};
/* harmony default export */ const page = (ProdcutsPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,8482,8191,7066,4389,6882,6558,9335,4119,2299,4649,1387,2706,7355,1512], () => (__webpack_exec__(35744)));
module.exports = __webpack_exports__;

})();