(() => {
var exports = {};
exports.id = 5282;
exports.ids = [5282];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 72254:
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ 6005:
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ 87561:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ 88849:
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ 22286:
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ 87503:
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ 49411:
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ 97742:
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ 84492:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ 72477:
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ 41041:
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ 47261:
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ 65628:
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 74105:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        '(user)',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95078)), "/app/app/(user)/page.js"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16365)), "/app/app/(user)/layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 63546)), "/app/app/(user)/not-found.jsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
const pages = ["/app/app/(user)/page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/(user)/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/(user)/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 85921:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 61896))

/***/ }),

/***/ 61896:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app/(user)/components/hero.jsx","import":"Montserrat","arguments":[{"weight":"700","subsets":["latin"]}],"variableName":"montserrat"}
var hero_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_ = __webpack_require__(34919);
var hero_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_default = /*#__PURE__*/__webpack_require__.n(hero_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_);
// EXTERNAL MODULE: ./lib/utils.js
var utils = __webpack_require__(84493);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/ui/button.jsx
var ui_button = __webpack_require__(4187);
// EXTERNAL MODULE: ./components/ui/card.jsx
var card = __webpack_require__(69924);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./components/spinner.jsx
var spinner = __webpack_require__(81023);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(93258);
;// CONCATENATED MODULE: ./app/(user)/components/components/download-card.jsx







const DownloadCard = ()=>{
    const [downloads, setDownloads] = (0,react_.useState)("10.5k");
    (0,react_.useEffect)(()=>{
        const fetchDownloads = async ()=>{
            try {
                // Send a GET request to the API endpoint
                const response = await axios/* default */.Z.get(`${"http://localhost:3004"}/api/products/download`);
                if (response.status === 200) {
                    // Get the data from the response
                    const data = response.data;
                    setDownloads(2479 + data.totalDownloads);
                } else {
                    console.error("Error fetching downloads:", response.status);
                }
            } catch (error) {
                console.log(error);
                setDownloads("10.5k");
                return;
            }
        };
        fetchDownloads();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* Card */.Zb, {
        className: "shadow-sm hover:none space-y-0 w-",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(card/* CardHeader */.Ol, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(card/* CardTitle */.ll, {
                    children: "Total downloads:"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* CardContent */.aY, {
                className: "flex justify-between ",
                children: [
                    downloads ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        className: "text-2xl font-semibold col-span-2",
                        children: [
                            downloads,
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-muted-foreground text-xl text-blue-400 col-span-1 ml-3",
                                children: "And counting"
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(spinner/* default */.Z, {
                        size: 8
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                        href: "/products",
                        children: [
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                varient: "outline",
                                className: "hover:scale-[102%] duration-100 transition-all h-max rounded-full text-sm sm:text-md lg:text-lg xl:text-xl font-semibold bg-gradient-to-r from-blue-600 to-indigo-800 shadow-xl border-2 border-white",
                                children: "Download Now"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const download_card = (DownloadCard);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./app/(user)/components/hero.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Hero = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex-grow container md:px-10  px:6 2xl:mt-44 xl:mt-36 lg:mt-28 mt-20  mb-2 2xl:mb-6  flex lg:flex-row flex-col gap-x-16 gap-y-4 w-full justify-between  items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " animate-fade-in-left flex flex-col gap-12 lg:w-[45%] w-full h-full justify-start py-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col gap-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-blue-500 fond-light",
                                children: "Empowering Developers with Unparalleled Tools!"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: "text-3xl sm:text-4xl lg:text-5xl text-gray-800 font-semibold",
                                children: [
                                    "Elevate Your Software Development Experience with",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (0,utils.cn)("text-blue-600 ", (hero_jsx_import_Montserrat_arguments_weight_700_subsets_latin_variableName_montserrat_default()).className),
                                        children: "Musesoft"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-muted-foreground text-lg",
                                children: "Embark on a journey of innovation and efficiency with our cutting-edge software applications tailored to enhance every step of your software development process."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(download_card, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " animate-fade-in-up flex lg:w-[45%] w-full h-full items-center justify-center text-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/images/hero-pic.png",
                    alt: "Pic error",
                    width: 600,
                    height: 600
                })
            })
        ]
    });
};
/* harmony default export */ const hero = (Hero);

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(51158);
;// CONCATENATED MODULE: ./app/(user)/components/components/our-products.jsx




const OurProducts = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-y-12 container items-center ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-gray-800 text-4xl lg:text-5xl font-bold",
                children: "Our Products"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "my-4 mx-auto w-20 h-2 -mt-6 bg-indigo-500"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/products",
                className: "animate-fade-in-left rounded-lg py-6 px-8  lg:w-[80%] w-full bg-white hover:scale-[101%] transition-transform duration-150 shadow-lg ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex md:flex-row flex-col gap-y-6 gap-x-16 items-center justify-between ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Logo",
                            src: "/icons/muse-icon.png",
                            width: 64,
                            height: 64
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "md:text-3xl text-2xl font-semibold text-center",
                            children: "Muse - Middleware Universal Scripting idE"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* ArrowRight */.olP, {
                            className: " w-8 h-8"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/products",
                className: "animate-fade-in-left rounded-lg py-6 px-8  lg:w-[80%] w-full bg-white hover:scale-[101%] transition-transform duration-150 shadow-lg ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex md:flex-row flex-col gap-y-6 gap-x-16 items-center justify-between ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Logo",
                            src: "/icons/jetpack-icon.png",
                            width: 64,
                            height: 64
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "md:text-3xl text-2xl font-semibold text-center",
                            children: "JETPack - Empowering JaButton Development environment"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* ArrowRight */.olP, {
                            className: " w-8 h-8"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const our_products = (OurProducts);

;// CONCATENATED MODULE: ./app/(user)/components/components/about-section.jsx

const AboutSection = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-y-12 container items-center ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-gray-800 text-4xl lg:text-5xl font-bold",
                children: "About Us"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "my-4 mx-auto w-20 h-2 -mt-6 bg-indigo-500"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-gray-700",
                children: "Welcome to Musesoft! We are a team of passionate and experienced developers who offer a diverse range of cutting-edge software solutions designed to enhance your development and automation experiences."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-gray-700 mt-2",
                children: "Whether you need a powerful scripting tool, a fast and reliable Java environment, or anything in between, we have the perfect software product for you. Our products are easy to use, highly customizable, and compatible with various platforms and frameworks."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-gray-700 mt-4",
                children: "Choose innovation and efficiency with our software products that redefine the way you develop, automate, and optimize your projects."
            })
        ]
    });
};
/* harmony default export */ const about_section = (AboutSection);

;// CONCATENATED MODULE: ./app/(user)/components/about.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const About = ()=>{
    const [buttonCliked, setButtonCLicked] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "curvey-top-bottom  flex flex-col gap-y-24 justify-center items-center w-screen h-auto flex-grow bg-[#F2F6F9] pb-28 pt-20  2xl:px-0 md:px-10 px-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (0,utils.cn)(" hidden xl:flex flex-col  gap-y-2 justify-center items-center animate-pulse", buttonCliked && "animate-none"),
                style: {
                    animationDuration: "2s"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                    id: "move",
                    onClick: ()=>{
                        document.querySelector("#move").scrollIntoView({
                            behavior: "smooth"
                        });
                        setButtonCLicked(true);
                    },
                    className: " bg-blue-500 font-semibold shadow-xl text-center text-lg h-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* ArrowDown */.K5e, {
                        className: "text-white"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(our_products, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(about_section, {})
        ]
    });
};
/* harmony default export */ const about = (About);

;// CONCATENATED MODULE: ./app/(user)/components/components/testimonial.jsx


const Testimonial = ({ testimonial })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rounded-lg shadow max-w-[24rem] w-[90%] h-[18rem] p-10 bg-white text-gray-700 leading-snug flex flex-col justify-between animate-fade-in-down",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "-ml-4",
                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    className: "w-8 opacity-25 text-indigo-500",
                    xmlns: "http://www.w3.org/2000/svg",
                    shapeRendering: "geometricPrecision",
                    textRendering: "geometricPrecision",
                    imageRendering: "optimizeQuality",
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    viewBox: "0 0 640 640",
                    fill: "currentColor",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M557.133 561.704H442.128c-44.256 0-80.458-36.19-80.458-80.446 0-165.58-42.32-347.485 160.656-399.418 91.95-23.516 115.915 77.753 18.119 84.745-59.647 4.276-71.293 42.804-73.147 101.068h92.269c44.256 0 80.458 36.201 80.458 80.458v130.702c0 45.591-37.3 82.89-82.891 82.89zm-358.032 0H84.096c-44.256 0-80.446-36.19-80.446-80.446 0-165.58-42.331-347.485 160.644-399.418 91.95-23.516 115.915 77.753 18.118 84.745-59.646 4.276-71.292 42.804-73.146 101.068h92.269c44.256 0 80.457 36.201 80.457 80.458v130.702c0 45.591-37.3 82.89-82.89 82.89z"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mt-2",
                children: testimonial.review
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mx-auto w-full border border-gray-300 my-8"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative w-12 h-12 rounded-full border-2 border-indigo-400",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    fill: true,
                                    alt: "Image",
                                    src: testimonial.pic || "https://imgv3.fotor.com/images/blog-richtext-image/10-profile-picture-ideas-to-make-you-stand-out.jpg",
                                    objectFit: "cover",
                                    className: "rounded-full border border-indigo-400"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "font-bold",
                                        children: testimonial.name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm text-gray-600 mt-1",
                                        children: testimonial.role
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_testimonial = (Testimonial);

;// CONCATENATED MODULE: ./app/(user)/components/components/infinite-scroling-div.jsx


function InfiniteTestimonials({ testimonials = [] }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full flex flex-wrap gap-6 justify-center items-center overflow-hidden px-4 [mask-image:_linear-gradient(to_right,transparent_0,_black_128px,_black_calc(100%-128px),transparent_100%)]",
        children: testimonials.slice(0, 3).map((testimonial, index)=>/*#__PURE__*/ jsx_runtime_.jsx(components_testimonial, {
                testimonial: testimonial,
                index: index + 1
            }, index))
    });
}
/* harmony default export */ const infinite_scroling_div = (InfiniteTestimonials);

// EXTERNAL MODULE: ./components/ui/skeleton.jsx
var skeleton = __webpack_require__(47440);
;// CONCATENATED MODULE: ./app/(user)/components/components/testimonial-skeletons.jsx


 // import the Skeleton component from shadcn ui
const TestimonialSkeletons = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full flex p-10 justify-between gap-8  flex-nowrap overflow-hidden [mask-image:_linear-gradient(to_right,transparent_0,_black_128px,_black_calc(100%-128px),transparent_100%)]",
        children: [
            1,
            2,
            3
        ].map((index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " animate-fade-in-down  rounded-lg shadow  w-full p-10 bg-white text-gray-700 leading-snug flex flex-col justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "-ml-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: "w-8 opacity-25 text-indigo-500",
                            xmlns: "http://www.w3.org/2000/svg",
                            shapeRendering: "geometricPrecision",
                            textRendering: "geometricPrecision",
                            imageRendering: "optimizeQuality",
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            viewBox: "0 0 640 640",
                            fill: "currentColor",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M557.133 561.704H442.128c-44.256 0-80.458-36.19-80.458-80.446 0-165.58-42.32-347.485 160.656-399.418 91.95-23.516 115.915 77.753 18.119 84.745-59.647 4.276-71.293 42.804-73.147 101.068h92.269c44.256 0 80.458 36.201 80.458 80.458v130.702c0 45.591-37.3 82.89-82.891 82.89zm-358.032 0H84.096c-44.256 0-80.446-36.19-80.446-80.446 0-165.58-42.331-347.485 160.644-399.418 91.95-23.516 115.915 77.753 18.118 84.745-59.646 4.276-71.292 42.804-73.146 101.068h92.269c44.256 0 80.457 36.201 80.457 80.458v130.702c0 45.591-37.3 82.89-82.89 82.89z"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-2 flex flex-col gap-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                className: "w-20"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                className: "w-32"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                className: "w-16"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                className: "w-28"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mx-auto w-full border border-gray-300 my-8"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                        className: " w-12 h-12 rounded-full border-2 border-indigo-400"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "ml-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                                className: "font-bold w-20 rounded-sm"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(skeleton/* Skeleton */.O, {
                                                className: "text-sm text-gray-600 mt-1 w-28 rounded-sm"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }, index))
    });
};
/* harmony default export */ const testimonial_skeletons = (TestimonialSkeletons);

;// CONCATENATED MODULE: ./app/(user)/components/testimonials.jsx





const Testimonials = ()=>{
    const [testimonials, setTesimonials] = (0,react_.useState)([]);
    const [loading, setLoading] = (0,react_.useState)(true);
    (0,react_.useEffect)(()=>{
        const fetchReviews = async ()=>{
            try {
                // Send a GET request to the API endpoint
                const response = await axios/* default */.Z.get(`${"http://localhost:3004"}/api/users/review`);
                if (response.status === 200) {
                    // Get the data from the response
                    const data = response.data;
                    setTesimonials(data.reviews);
                } else {
                    throw new Error(response.statusText);
                }
            } catch (error) {
                console.error(error);
            } finally{
                setLoading(false);
            }
        };
        fetchReviews();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-screen bg-slate-100 mb-16",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col gap-16 container py-16  text-gray-900",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-center text-gray-800 text-4xl lg:text-5xl font-bold leading-tight",
                            children: "Testimonials"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "my-4 mx-auto w-20 h-2  bg-indigo-500"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-center text-gray-700 font-light text-lg",
                            children: "Here are what some of our amazing customers are saying ..."
                        })
                    ]
                }),
                loading || testimonials?.length === 0 ? /*#__PURE__*/ jsx_runtime_.jsx(testimonial_skeletons, {}) : /*#__PURE__*/ jsx_runtime_.jsx(infinite_scroling_div, {
                    testimonials: testimonials
                })
            ]
        })
    });
};
/* harmony default export */ const testimonials = (Testimonials);

// EXTERNAL MODULE: ./components/ui/sheet.jsx
var sheet = __webpack_require__(45279);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(66558);
// EXTERNAL MODULE: ./node_modules/@hookform/resolvers/zod/dist/zod.mjs + 1 modules
var zod = __webpack_require__(83894);
// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(19098);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(10345);
// EXTERNAL MODULE: ./node_modules/@clerk/clerk-react/dist/esm/index.js + 54 modules
var esm = __webpack_require__(64470);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-label/dist/index.mjs
var react_label_dist = __webpack_require__(43618);
// EXTERNAL MODULE: ./node_modules/class-variance-authority/dist/index.mjs
var class_variance_authority_dist = __webpack_require__(91971);
;// CONCATENATED MODULE: ./components/ui/label.jsx
/* __next_internal_client_entry_do_not_use__ Label auto */ 




const labelVariants = (0,class_variance_authority_dist/* cva */.j)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_label_dist/* Root */.f, {
        ref: ref,
        className: (0,utils.cn)(labelVariants(), className),
        ...props
    }));
Label.displayName = react_label_dist/* Root */.f.displayName;


;// CONCATENATED MODULE: ./app/(user)/components/review-from.jsx










// Define the schema for the review form
const reviewSchema = lib/* object */.Ry({
    name: lib/* string */.Z_().min(1),
    role: lib/* string */.Z_().min(1),
    review: lib/* string */.Z_().min(50)
});
// Define the component for the review form
const ReviewForm = ({ setIsOpen })=>{
    // Use react-hook-form with zod resolver
    const { register, handleSubmit, formState: { errors } } = (0,index_esm/* useForm */.cI)({
        resolver: (0,zod/* zodResolver */.F)(reviewSchema)
    });
    // Get the user data from clerk useUser hook
    const user = (0,esm/* useUser */.aF)();
    // Define the submit handler
    const onSubmit = async (data)=>{
        // Display a loading toast
        dist/* default */.ZP.loading("Sending the review");
        try {
            // Send the data to the API endpoint
            const response = await axios/* default */.Z.post(`${"http://localhost:3004"}/api/users/review/${user?.user?.id}`, {
                ...data,
                pic: user.user.imageUrl
            }, {
                headers: {
                    "Content-Type": "application/json"
                }
            });
            dist/* default */.ZP.dismiss();
            // Check if the response is successful
            if (response.status === 200) {
                // Close the sheet and display a success toast
                setIsOpen(false);
                dist/* default */.ZP.success("Thank you for the review");
            } else if (response.status === 500) {
                let responseData = response.data;
                dist/* default */.ZP.error(responseData.error);
            } else {
                // Display an error toast
                dist/* default */.ZP.error("There was an error while submitting the review");
            }
        } catch (error) {
            // Display an error toast
            console.log(error);
            dist/* default */.ZP.dismiss();
            dist/* default */.ZP.error("There was an error while submitting the review");
        }
    };
    // Return the JSX element for the form
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        className: "flex flex-col space-y-6 py-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid w-full max-w-sm items-center gap-1.5",
                "aria-disabled": true,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                        htmlFor: "name",
                        children: "Name"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        id: "name",
                        type: "text",
                        value: user?.user.fullName,
                        ...register("name"),
                        className: "border-2 rounded-md p-2"
                    }),
                    errors.name && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-xs text-red-500",
                        children: errors.name.message?.replace("String", "Name")
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid w-full max-w-sm items-center gap-1.5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                        htmlFor: "role",
                        children: "Role"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "border-2 rounded-md p-2",
                        id: "role",
                        type: "text",
                        placeholder: "e.g Software Engineer, Student",
                        ...register("role")
                    }),
                    errors.roles && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-xs text-red-500",
                        children: errors.roles.message?.replace("String", "Role")
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid w-full gap-1.5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Label, {
                        htmlFor: "review",
                        children: "Review"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        className: "border-2 rounded-md p-2",
                        id: "review",
                        rows: 4,
                        ...register("review"),
                        placeholder: "Minimum 50 characters"
                    }),
                    errors.review && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-xs text-red-500",
                        children: errors.review.message?.replace("String", "Review")
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between gap-4 flex-wrap",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        type: "submit",
                        className: "px-4 py-2  text-white rounded-md",
                        children: "Submit"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(sheet/* SheetFooter */.FF, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(sheet/* SheetClose */.sw, {
                            asChild: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                className: "",
                                variant: "outline",
                                children: "Cancel"
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const review_from = (ReviewForm);

;// CONCATENATED MODULE: ./app/(user)/components/review-container.jsx









const ReviewContainer = ()=>{
    const [bought, setBought] = (0,react_.useState)(false);
    const [isOpen, setIsOpen] = (0,react_.useState)(false);
    const user = (0,esm/* useUser */.aF)();
    (0,react_.useEffect)(()=>{
        const fetchBoughtStatus = async ()=>{
            try {
                // Send a GET request to the API endpoint
                const response = await axios/* default */.Z.get(`${"http://localhost:3004"}/api/users/product/${user?.user?.id}`);
                // Check if the response is successful
                if (response.status === 200) {
                    // Get the data from the response
                    const data = response.data;
                    setBought(data);
                }
            } catch (error) {
                // Display an error toast
                console.error(error);
            }
        };
        if (user?.isSignedIn) fetchBoughtStatus();
    }, [
        user?.isSignedIn
    ]);
    // Return the JSX element for the main page
    return bought ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                onClick: ()=>setIsOpen(true),
                className: (0,utils.cn)("fixed bottom-8 right-8 z-10 md:text-2xl text-xl h-16 bg-indigo-600 rounded-3xl shadow-xl border-2 animate-pulse", isOpen && "hidden"),
                size: "lg",
                children: "Write a review"
            }),
            " ",
            /*#__PURE__*/ jsx_runtime_.jsx(sheet/* Sheet */.yo, {
                open: isOpen,
                onOpenChange: ()=>setIsOpen(false),
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(sheet/* SheetContent */.ue, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(sheet/* SheetHeader */.Tu, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(sheet/* SheetTitle */.bC, {
                                    children: "Give us a review"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(sheet/* SheetDescription */.Ei, {
                                    children: "We appreciate your feedback. Please fill out the form below and click submit when you're done."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(review_from, {
                            setIsOpen: setIsOpen
                        })
                    ]
                })
            })
        ]
    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
};
/* harmony default export */ const review_container = (ReviewContainer);

;// CONCATENATED MODULE: ./app/(user)/page.js
/* __next_internal_client_entry_do_not_use__ default auto */ 




function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-y-10 w-screen scroll-smooth",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(hero, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(about, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(testimonials, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(review_container, {})
        ]
    });
}


/***/ }),

/***/ 81023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84493);


const Spinner = ({ size })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        style: {
            animationDuration: "3s"
        },
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_1__.cn)("border-[6px] border-dashed border-blue-700 rounded-full animate-spin", `w-${size} h-${size} ${size === 8 && "border-[4px]"}`)
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Spinner);


/***/ }),

/***/ 95078:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/app/app/(user)/page.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3587,8482,8191,7066,4389,6882,6558,9335,4119,4349,1387,2706,7355,5279,9924], () => (__webpack_exec__(74105)));
module.exports = __webpack_exports__;

})();