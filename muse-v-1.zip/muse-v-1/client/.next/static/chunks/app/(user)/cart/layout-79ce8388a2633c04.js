(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[195],{7263:function(e,r,t){Promise.resolve().then(t.bind(t,7277))},7277:function(e,r,t){"use strict";t.r(r);var n=t(7437),s=t(2265);r.default=e=>{let{children:r}=e,[t,o]=(0,s.useState)(!1);return(0,s.useEffect)(()=>{o(!0)},[]),(0,n.jsx)(n.Fragment,{children:t?(0,n.jsx)("div",{className:"w-full h-max",children:r}):(0,n.jsx)("div",{className:"w-full h-full flex justify-center items-center",children:(0,n.jsx)("span",{style:{animationDuration:"3s"},className:"w-16 h-16 border-[6px] border-dashed border-blue-700 rounded-full animate-spin"})})})}},622:function(e,r,t){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=t(2265),s=Symbol.for("react.element"),o=Symbol.for("react.fragment"),l=Object.prototype.hasOwnProperty,u=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,a={key:!0,ref:!0,__self:!0,__source:!0};function f(e,r,t){var n,o={},f=null,i=null;for(n in void 0!==t&&(f=""+t),void 0!==r.key&&(f=""+r.key),void 0!==r.ref&&(i=r.ref),r)l.call(r,n)&&!a.hasOwnProperty(n)&&(o[n]=r[n]);if(e&&e.defaultProps)for(n in r=e.defaultProps)void 0===o[n]&&(o[n]=r[n]);return{$$typeof:s,type:e,key:f,ref:i,props:o,_owner:u.current}}r.Fragment=o,r.jsx=f,r.jsxs=f},7437:function(e,r,t){"use strict";e.exports=t(622)}},function(e){e.O(0,[971,596,744],function(){return e(e.s=7263)}),_N_E=e.O()}]);