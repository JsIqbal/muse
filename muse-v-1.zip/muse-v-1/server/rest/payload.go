package rest

type Payload struct {
	ID string `json:"id"`
}
