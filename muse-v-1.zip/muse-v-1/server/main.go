package main

import "go-rest/cmd"

func main() {
	cmd.Execute()
}
