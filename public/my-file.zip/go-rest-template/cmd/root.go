package cmd

func Execute() {
	serveRest()
}
